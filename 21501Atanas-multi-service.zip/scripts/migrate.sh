#!/usr/bin/env bash
echo "No migrations to run."
