# 21501Atanas Multi-Service Project

## Структура
- `backend/` – Node.js API
- `database/` – PostgreSQL init
- `nginx/` – обратен прокси конфиг
- `scripts/` – помощни скриптове
- `compose.yaml` – обща дефиниция
- `compose.dev.yml` – за development
- `compose.prod.yml` – за production
- `Makefile` – shortcut команди

## Инструкции

### Build & Up (dev)
```
make build
make up
```

- API: `http://localhost:3000`  
- Nginx: `http://localhost`

### Down & Logs
```
make down
make logs
```

## Публикуване

1. GitHub: `https://github.com/21501Atanas/multi-service`  
2. Docker Hub образы:
   - `21501atanas/backend:latest`
   - `21501atanas/database:latest`
